from django.contrib import admin
from django.urls import path

from connectapp.views import (
    connect, logout_view, consult, edit, #register, 
    home
)

urlpatterns = [
    path('admin/', admin.site.urls),
    path('login/', connect, name="login"),
    path('logout/', logout_view, name="logout"),
    path('home/', home, name="home"),
    path('consult/', consult, name="consult"),
    path('edit/', edit, name="edit"),
    #path('register/', register, name="register"),
    
]
