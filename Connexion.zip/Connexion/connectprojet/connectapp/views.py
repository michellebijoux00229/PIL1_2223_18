from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from .models import Etudiant 
from .forms import RowInscriForm, LoginForm
AUTH_USER_MODEL = 'connectapp.Etudiant'

def logout_view(request):
    logout(request)
    messages.success(request, 'Vous êtes maintenant déconnecté.')
    return redirect('login')

def consult(request):
    return render(request, 'consult.html')



"""def connect(request):
    form=LoginForm(request.POST)
    if form.is_valid():
        username=form.cleaned_data['matricule']
        password=form.cleaned_data['Mot_de_passe']
        utilisateur=Etudiant.objects.get(username=username)
        utilpassw=Etudiant.objects.get(password=password)
        if (username==utilisateur.username):
         if password==utilpassw.password:
            return redirect ('http://127.0.0.1:8000/consult/')
        else:
            print('',username)
            print('',password)
            print('',utilisateur)
            print('',utilpassw)"""
        #return redirect (login)


def connect(request):
    if request.method == "POST":
        matricule = request.POST.get('matricule')
        password = request.POST.get('password')
        user = authenticate(request, username=matricule, password=password)
        if user is not None:
            login(request, user)
            return redirect('consult')
        else:
            messages.error(request, 'Identifiant incorrect')
            return redirect('login')
    else:
        form = LoginForm()
        return render(request, 'index.html', {})




            #return redirect('login')
    #else:
        """  print('',username)
            print('',password)
            print('',utilisateur)
            print('',utilpassw)"""
        #return redirect('login')
        # return render(request, 'index.html', {})










    """if request.method == "POST":
        matricule = request.POST.get('matricule')
        password = request.POST.get('password')
        user = authenticate(request, username=matricule, password=password)
        if user is not None:
            login(request, user)
            #prenom = user.prenometu
        return redirect('consult.html')
        else:
            messages.error(request, 'Identifian incorrect')
            return redirect('login')
    else:
        form = LoginForm()
        return render(request, 'index.html', {'form': form}) """

def home(request):
    return render(request, 'index.html', {})

def edit(request):
    return render(request, 'edition.html', {})

"""def register(request):
    if request.method == "POST":
        form = RowInscriForm(request.POST)
        nom= request.POST['nom']
        prenom = request.POST['prenom']
        email = request.POST['email']
        matricule = request.POST['matricule']
        password = request.POST['password']
        utilisateur = Etudiant.objects.create_user(username=matricule, email=email, password=password)
        utilisateur.nometu = nom
        utilisateur.prenometu = prenom
        utilisateur.save()
        messages.success(request, 'Votre compte a été créé avec succès.')
        return redirect('login')
    else:
        form = RowInscriForm()
    return render(request, 'inscriptionform.html', {'form': form})"""
"""
def login_view(request):
    #if request.method == "POST":
    matricules = Etudiant.matricule.object.all()
    context={'matricule': matricules}
    if matricule in matricules:
        if password == Etudiant.objects.password:
            return render(request, 'consult.html', {})
        else:
            return render(request, 'index.html', {})"""

""" matricule = request.POST.get('matricule')
    password = request.POST.get('password')
    mat = Etudiant.matricule
    pasw = Etudiant.password
    pasw=password
    if (matricule == mat and password==pasw):
     return render(request, 'consult.html', {})
    else:
         return redirect ('home')"""
"""user = authenticate(request, username=matricule, password=password)
   if user is not None:
            login(request, user)
        return redirect('consult')"""
    
"""else:
            messages.error(request, 'Identifiant incorrect')
            return redirect('login')"""
""" else:
   form = LoginForm()
        return render(request, 'index.html', {'form': form})
def """