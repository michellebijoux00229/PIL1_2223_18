from django.contrib import admin
from .models import Etudiant

class AdminEtudiant(admin.ModelAdmin):
    list_display = ('nometu', 'prenometu', 'email')

admin.site.register(Etudiant, AdminEtudiant)
