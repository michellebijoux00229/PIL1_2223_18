from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from .models import Etudiant

class RowInscriForm(UserCreationForm):
    nom = forms.CharField(max_length=100)
    prenom = forms.CharField(max_length=100)
    email = forms.EmailField()
    promotion = forms.CharField(max_length=100)
    matricule = forms.CharField(max_length=100)
    password = forms.CharField(max_length=100)

    class Meta:
        model = Etudiant
        fields = ('nom', 'prenom', 'email', 'promotion', 'matricule', 'password1', 'password2')

class LoginForm(forms.Form):
    username=forms.CharField(max_length=100)
    password=forms.CharField(max_length=100, widget=forms.PasswordInput)


"""class LoginForm(AuthenticationForm):
    matricule = forms.CharField(max_length=100)
    password = forms.CharField(widget=forms.PasswordInput)"""

"""class Meta:
        model = Etudiant
        fields = ('matricule', 'password')"""



"""from django import forms

class RowInscriForm(forms.Form):
    nom = forms.CharField()
    prenom = forms.CharField()
    email = forms.EmailField()
    promotion = forms.CharField()
    matricule = forms.CharField()
    password = forms.CharField()

class LoginForm()

"""