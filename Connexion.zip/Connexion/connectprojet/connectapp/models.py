from django.db import models
from django.contrib.auth.models import AbstractUser, Group, Permission

class Etudiant(AbstractUser):
    nometu = models.CharField(max_length=100)
    prenometu = models.CharField(max_length=100)
    matricule = models.CharField(max_length=100)
    email = models.EmailField(default='example@example.com')
    password =  models.CharField(max_length=100)
    groups = models.ManyToManyField(Group, related_name='etudiants')
    user_permissions = models.ManyToManyField(Permission, related_name='etudiants_permissions')
    
    def __str__(self):
        return f"{self.nometu} {self.prenometu} {self.email}"


class profil(models.Model):
    username=models.CharField(max_length=100, unique=True)
    password=models.CharField(max_length=100)
def __str__(self):
        return self.username








"""from django.db import models



class Etudiant(models.Model):
    idetu = models.TextField()
    nometu = models.CharField(max_length=250)
    prenometu = models.CharField(max_length=250)
    promoetu = models.CharField(max_length=250)
    emailetu = models.EmailField()
    motdepasseetu = models.TextField()
    retapmdp = models.TextField()
    idfiliere = models.TextField()

    class Meta:
        db_table = 'Etudiant'
        managed = True
        verbose_name = ('Etudiant')
        verbose_name_plural = ('Etudiants')

class Admininistrateur(models.Model):
    idadmin = models.TextField()
    nomadmin = models.CharField(max_length=250)
    prenomadmin = models.CharField(max_length=250)
    posteadmin = models.CharField(max_length=250)
    emailadmin = models.EmailField()
    motdepasseadmin = models.TextField()
    retapmdpadmin = models.TextField()

    class  Meta:
        db_table = 'Administrateur'
        managed = True
        verbose_name = ('Administrateur')
        verbose_name_plural = ('Administrateurs')

    def __str__(self):
        return self.idetu, self.idamin

    class userProfile(models.Model):
        user = models.OneToOneField(Etudiant, on_delete=models.CASCADE)
        password = models.TextField(max_length=250)
"""