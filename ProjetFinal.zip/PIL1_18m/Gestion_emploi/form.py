from django import forms
from .models import creation_emploie_du_temps,  Etudiant, profil




class RowFormEmploi(forms.ModelForm):
        
        semaine = forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}))
        promotion = forms.CharField(max_length=255)
        matière = forms.CharField(max_length=255)
        masse_horaire = forms.IntegerField()
        temps_restant = forms.IntegerField()
        professeur = forms.CharField(max_length=255)
        salle = forms.CharField(max_length=100)
        jour = forms.CharField(max_length=30) 
        heure_debut = forms.TimeField(widget=forms.TimeInput(attrs={'type': 'time'}))
        heure_fin = forms.TimeField(widget=forms.TimeInput(attrs={'type': 'time'}))

    
        class Meta:
       
            model = creation_emploie_du_temps
        
            fields = ['id_emploie', 'semaine','promotion', 'matière',  'masse_horaire', 'temps_restant', 'professeur', 'salle', 'jour', 'heure_debut', 'heure_fin']


class RowFormprofil(forms.ModelForm):
    class Meta:
        model = profil
        fields = ['username', 'password']
        widgets = {
            'password': forms.PasswordInput()  # Masquer le champ de mot de passe
        }





from django.core.validators import MinValueValidator, MaxValueValidator

class RowFormInscri(forms.ModelForm):
    nom = forms.CharField(max_length=255)
    prenom = forms.CharField(max_length=255)
    email = forms.EmailField()
    promo = forms.CharField(max_length=255)
    matricule = forms.IntegerField(
        widget=forms.TextInput(attrs={'type': 'number', 'step': 'any'}),
        validators=[MinValueValidator(1), MaxValueValidator(99999999)]
    )
    password = forms.CharField(widget=forms.PasswordInput())

    class Meta:
        model = Etudiant
        fields = ['nom', 'prenom', 'email', 'promo', 'matricule', 'password']



class RowFormlog(forms.ModelForm):
     matricule = forms.CharField(max_length=255)
     password = forms.CharField(widget=forms.PasswordInput())

     class Meta :
          model = Etudiant
          fields = ['matricule', 'password']


class RowFormmdp(forms.ModelForm):
     email = forms.EmailField()
     matricule = forms.NumberInput()
     
     class Meta :
          Model = Etudiant
          fields = ['email', 'matricule']



"""class RowFormInscri(forms.ModelForm):
      nom = forms.CharField(max_length=255)
      prenom = forms.CharField(max_length=255)
      email = forms.EmailField()
      promo = forms.Select()
      matricule = forms.IntegerField(widget=forms.TextInput(attrs={'type':'number', 'slep':'any'}))
      password = forms.PasswordInput()

      class Meta:
          model = Etudiant
          fields = ['nom', 'prenom', 'email', 'promo', 'matricule', 'password']
          widgets = {
              'password': forms.PasswordInput(),
          }"""



















    # Début_sem = forms.TimeField(widget=forms.TimeInput(attrs={'type': 'time'}))