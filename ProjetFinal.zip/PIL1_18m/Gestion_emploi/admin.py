from django.contrib import admin
from .models import creation_emploie_du_temps, Etudiant, profil

# Register your models here.
class Admincréation_emploie_du_temps(admin.ModelAdmin):
    list_display = ('id_emploie', 'semaine','promotion', 'matière',  'masse_horaire', 'temps_restant', 'professeur', 'salle', 'jour', 'heure_debut', 'heure_fin')
admin.site.register(creation_emploie_du_temps, Admincréation_emploie_du_temps)

class AdminEtudiant(admin.ModelAdmin):
    list_display = ('matricule','nom', 'prenom', 'email', 'promo', 'password',)
admin.site.register(Etudiant, AdminEtudiant)

class Adminprofil(admin.ModelAdmin):
    list_display = ('username', 'password')
admin.site.register(profil, Adminprofil)

"""class AdminEmplois(admin.ModelAdmin):
    list_display = ('id_emploie', 'semaine', 'promotion', 'matiere', 'masse_horaire', 'temps_restant', 'professeur', 'salle', 'jour', 'heure_debut', 'heure_debut')
admin.site.register(Emplois, AdminEmplois)"""