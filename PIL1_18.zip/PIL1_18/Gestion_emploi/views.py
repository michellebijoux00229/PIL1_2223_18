from django.shortcuts import render , redirect
from .models import creation_emploie_du_temps, Etudiant
from .form import RowFormEmploi, RowFormInscri, RowFormlog
from django.contrib.auth import authenticate, login, logout
from django.db import IntegrityError
from django.contrib import messages


def emploi(request):
    return render(request, "consult.html",{})




def insc(request):
    return render(request, "inscriptionform.html", {})



def home(request):
    return render(request, "index.html", {})

def connect(request):
    if request.method == 'POST':
        form = RowFormlog(request.POST)
        matricule = request.POST['matricule']
        password = request.POST['password']
        if form.is_valid():
           
            try:
                etudiant = Etudiant.objects.get(matricule=matricule)
                if etudiant.password == password:
                    user = authenticate(request,username=matricule, password=password)                    
                    login(request, user)
                    return redirect('consultation')
                     # Rediriger vers la page de tableau de bord après la connexion réussie
                else:
                    messages.error(request, "Mot de passe incorrect.")
            except Etudiant.DoesNotExist:
                messages.error(request, "Matricule introuvable.")
        else:
            form = RowFormlog()
            return render(request, 'index.html')


#

def inscrip(request):
    if request.method == 'POST':
        form = RowFormInscri(request.POST)
        nom = request.POST['nom']
        prenom = request.POST['prenom']
        email = request.POST['email']
        promo = request.POST['promo']
        matricule = request.POST['matricule']
        password = request.POST['password']
        etudiant = Etudiant(nom=nom, prenom=prenom, email=email, promo=promo, matricule=matricule)
        etudiant.set_password(password)



        if form.is_valid():

            try:
                form.save()
                messages.success(request, "Inscription réussie.")
                return redirect('connect')
            
            except IntegrityError:
                    messages.error(request, "Erreur lors de l'inscription.")
        else:
            form = RowFormInscri()

            return render(request, 'inscriptionform.html', {'form': form})



#form.cleaned_data



"""def inscrip(request):
    if request.method == 'POST':
        form = RowFormInscri(request.POST)
        nom = request.POST('nom')
        prenom = request.POST('prenom')
        email = request.POST('email')
        promo = request.POST('promo')
        matricule = request.POST('matricule')
        password = request.Post('password')

        if form.is_valid():

            try:
                form.save()
                messages.success(request, "Inscription réussie.")
                return redirect('insc')
            except IntegrityError:
                messages.error(request, "erreur")
        else:
            form = RowFormInscri()
    return render(request,  'inscriptionform.html', {'form':form})
"""





#def Edition_emploi(request,*args, **kwargs):
#instances = création_emploie_du_temps.objects.all
      #return render(request, 'Editer.html', {'instances': instances})"""
    

def Edition_emploi(request):
    if request.method == 'POST':
        form = RowFormEmploi(request.POST)
        semaine = request.POST['semaine']
        promotion = request.POST['promotion']
        matière = request.POST['matière']
        masse_horaire = request.POST['masse_horaire']
        temps_restant = request.POST['temps_restant']
        professeur = request.POST['professeur']
        salle = request.POST['salle']
        jour = request.POST['jour']
        heure_debut = request.POST['heure_debut']
        heure_fin = request.POST['heure_fin']

        if form.is_valid():
            
            try:
                form.save()
                messages.success(request, "Les données ont été enregistrées avec succès.")
                return redirect('Edition_emploi')
            except IntegrityError:
                messages.error(request, "Une erreur d'intégrité s'est produite lors de l'enregistrement des données.")
    else:
        form = RowFormEmploi()
    
    return render(request, 'Edition.html' , {'form': form})







                




