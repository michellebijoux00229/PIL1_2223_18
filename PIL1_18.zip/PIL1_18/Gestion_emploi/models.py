from django.db import models
from datetime import date
from django.contrib.auth.models import AbstractBaseUser,  Group, Permission, BaseUserManager, PermissionsMixin
#AbstractUser, 



class creation_emploie_du_temps(models.Model):
        id_emploie = models.AutoField(primary_key=True)
        semaine = models.DateField()
      
        promotion = models.CharField(max_length=255, null=False, blank=False) 

        matière = models.CharField(max_length=255)
        masse_horaire = models.PositiveIntegerField(editable=True)
        temps_restant = models.PositiveIntegerField(editable=True)
        professeur = models.CharField(max_length=255)
        salle = models.CharField(max_length=100)
       
        jour = models.CharField(max_length=30)

        heure_debut = models.TimeField(auto_now=False, auto_now_add=False)
        heure_fin = models.TimeField(auto_now=False, auto_now_add=False)
        
        
       

        class Meta:
                verbose_name = ('création-emploie_du_temps')
                verbose_name_plural = ('création-emploie_du_temps')
        def __str__(self):
                return f"{self.id_emploie} -{self.semaine}  - {self.promotion} - {self.matière} - {self.masse_horaire}- {self.temps_restant}- {self.professeur}-  {self.salle} - {self.jour} - {self.heure_debut} - {self.heure_fin}" 







class EtudiantManager(BaseUserManager):
    def create_user(self, email, password=None, **extra_fields):
        if not email:
            raise ValueError("L'adresse e-mail doit être spécifiée.")
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)

        if extra_fields.get('is_staff') is not True:
            raise ValueError("Le superutilisateur doit être assigné à is_staff=True.")
        if extra_fields.get('is_superuser') is not True:
            raise ValueError("Le superutilisateur doit être assigné à is_superuser=True.")

        return self.create_user(email, password, **extra_fields)




class Etudiant(AbstractBaseUser, PermissionsMixin):
    nom = models.CharField(max_length=255)
    prenom = models.CharField(max_length=255)
    email = models.EmailField(unique=True)
    promo = models.CharField(max_length=255)
    matricule = models.PositiveBigIntegerField(primary_key=True)
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)

    objects = EtudiantManager()

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['nom', 'prenom', 'promo']

    groups = models.ManyToManyField(Group, related_name='etudiants_groups')
    user_permissions = models.ManyToManyField(Permission, related_name='etudiants_permissions')

    class Meta:
        verbose_name = 'Etudiant'
        verbose_name_plural = 'Etudiants'

    def __str__(self):
        return f"{self.nom} - {self.promo} - {self.prenom} - {self.matricule} - {self.email}"














"""class Etudiant(AbstractUser):
      nom = models.CharField(max_length=255)
      prenom = models.CharField(max_length=255)
      email = models.EmailField()
      promo = models.CharField(max_length=255)
      matricule = models.PositiveBigIntegerField(primary_key=True, editable=True )
      password = models.CharField(max_length=255)
      groups = models.ManyToManyField(Group, related_name='etudiants')
      user_permissions = models.ManyToManyField(Permission, related_name='etudiants_permissions')  


      class Meta:
                verbose_name = 'Etudiant'
                verbose_name_plural = 'Etudiants'
        
      def __str__(self):
        return f"{self.nom} - {self.promo}- {self.prenom} - {self.matricule} - {self.password} - {self.email}"
"""




      






''' CHOIX_PROMO = (
        ('Licence 1 Groupe 1', 'Licence 1 Groupe 1'),
        ('Licence 1 Groupe 2', 'Licence 1 Groupe 2'),
        ('Licence 2 GL', 'Licence 2 GL'),
        ('Licence 2 IM', 'Licence 2 IM'),
        ('Licence 2 IA', 'Licence 2 IA'),
        ('Licence 2 SI', 'Licence 2 SI'),
        ('Licence 2 IA', 'Licence 2 IA'),
        ('Licence 2 SEIoT', 'Licence 2 SEIoT'),
        ('Licence 3 GL',  'Licence 3 GL'),
        ('Licence 3 IM',  'Licence 3 IM'),
        ('Licence 3 IA', 'Licence 3 IA'),
        ('Licence 3 SI', 'Licence 3 SI'),
        ('Licence 3 IA', 'Licence 3 IA'),
        ('Licence 3 SEIoT', 'Licence 3 SEIoT'),
        ('Master 1', 'Master 1'),.
        ('Master 2', 'Master 2'),
    )



CHOIX_SALLE = (
                ('Lundi', 'Lundi'),
                ('Mardi', 'Mardi'),
                ('Mercredi', 'Mercredi'),
                ('Jeudi', 'Jeudi'),
                ('Vendredi', 'Vendredi'),
                ('Samedi', 'Samedi'),
                
        )'''

#choices=CHOIX_SALLE# 