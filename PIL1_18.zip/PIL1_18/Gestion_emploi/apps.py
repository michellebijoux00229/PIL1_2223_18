from django.apps import AppConfig


class GestionEmploiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Gestion_emploi'
