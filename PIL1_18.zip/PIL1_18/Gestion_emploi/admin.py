from django.contrib import admin
from .models import creation_emploie_du_temps, Etudiant

# Register your models here.
class Admincréation_emploie_du_temps(admin.ModelAdmin):
    list_display = ('id_emploie', 'semaine','promotion', 'matière',  'masse_horaire', 'temps_restant', 'professeur', 'salle', 'jour', 'heure_debut', 'heure_fin')
admin.site.register(creation_emploie_du_temps, Admincréation_emploie_du_temps)

class AdminEtudiant(admin.ModelAdmin):
    list_display = ('matricule','nom', 'prenom', 'email', 'promo', 'password',)
admin.site.register(Etudiant, AdminEtudiant)