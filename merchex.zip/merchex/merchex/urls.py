from django.urls import path
from listings.views import supprimer_emploi_du_temps

urlpatterns = [

    path('emploi/supprimer/<int:emploi_id>/', supprimer_emploi_du_temps, name='supprimer_emploi_du_temps'),
]