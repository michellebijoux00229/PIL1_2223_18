from django.shortcuts import get_object_or_404
from django.http import HttpResponse

from listings.models import EmploiDuTemps

def supprimer_emploi_du_temps(request, emploi_id):
    emploi = get_object_or_404(EmploiDuTemps, id=emploi_id)
    emploi.delete()
    return HttpResponse("L'emploi du temps a été supprimé avec succès.")