from django.db import models

class EmploiDuTemps(models.Model):
    jour = models.CharField(max_length=50)
    heure_debut = models.TimeField()
    heure_fin = models.TimeField()
    cours = models.CharField(max_length=100)
    professeur = models.CharField(max_length=100)


    def __str__(self):
        return self.jour